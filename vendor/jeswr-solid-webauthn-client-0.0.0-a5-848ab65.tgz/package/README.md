# @jeswr/solid-webauthn-client

Redirect-free Solid-OIDC re-authentication with a WebAuthn (passkey) assertion —
the **framework-agnostic client** for the mechanism specified in
`spec/index.bs`. Pairs with `@jeswr/solid-webauthn-protocol` (the shared wire
contract) and drops into the apps' `@solid/reactive-authentication`
`TokenProvider[]` pipeline.

## What it does

On a `401 WWW-Authenticate: DPoP`, `WebAuthnTokenProvider.upgrade(request)`:

1. generates one non-extractable ES256 DPoP keypair/handle for the whole upgrade;
2. fetches a single-use challenge from the OP assertion-options endpoint;
3. runs `navigator.credentials.get()` (the app is the Relying Party — the signed
   `clientDataJSON.origin` unspoofably attests the app);
4. exchanges the assertion bundle at the token endpoint (RFC 8693,
   `urn:solid:token-type:webauthn-assertion`) for a DPoP-bound `at+jwt`; and
5. returns the request upgraded with `Authorization: DPoP <token>` + a
   resource-bound `DPoP` proof (the token-endpoint proof and the resource proof
   share one key — RFC 9449 sender-constraint continuity).

```ts
import { WebAuthnTokenProvider } from "@jeswr/solid-webauthn-client";

const provider = new WebAuthnTokenProvider({
  "broker.example.org": {
    issuer: "https://broker.example.org",
    clientId: "https://app.example/clientid.jsonld", // the app's Client ID Document
    // assertionOptionsEndpoint defaults to <issuer>/.oidc/webauthn/assertion-options
    // tokenEndpoint defaults to the OIDC-discovered token_endpoint
  },
});

// Register before the interactive popup provider so passkey re-auth is tried
// silently first; first `matches` wins:
//   providers = [provider, ...interactiveProviders]
```

## The reuse decision (why this package exists, minimally)

This package is **A5** of the passkey port (`docs/passkey-webauthn-port-design.md`
§5). The maintainer asked whether a new client package is needed at all, given a
WebAuthn client already exists in CSS. The investigation:

| Library | What it is | `DPoPTokenProvider` shape | `TokenExchange` Strategy seam? |
|---|---|---|---|
| `@solid/reactive-authentication@0.1.3` (**what the apps use** — Pod Manager's vendored `…-0.1.3-pr11-14.tgz`) | published Solid fork (`solid-contrib/reactive-authentication`) | `(callbackUri, getCodeCallback, getIssuerCallback)` | **No** — no `TokenExchange`/`OidcTokenExchange`/`WebAuthnTokenExchange` in its `dist` |
| `reactive-authentication-js` (**what the CSS WebAuthn client subclasses**) | Samu Lang's original, *hydrated* into this workspace via `bootstrap.sh`, **not** a published workspace member | `(exchange: TokenExchange \| GetCodeCallback)` | **Yes** — the Strategy seam `WebAuthnTokenExchange` plugs into |

**Same lineage, diverged seam.** Both are authored by Samu Lang and share the
minimal `TokenProvider` interface (`matches`/`upgrade`/optional `invalidate`).
But the published library the apps consume **dropped** the `TokenExchange`
Strategy seam, so the fork's `WebAuthnTokenProvider extends
DPoPTokenProvider(new WebAuthnTokenExchange(...))` **cannot** subclass it — there
is nothing to inject the exchange into.

**Decision — maximal reuse, minimal new code:**

- **Reused verbatim (logic):** `WebAuthnTokenExchange` (the entire assertion-
  options → ceremony → RFC 8693 exchange) and `dpopBoundRequest` — both already
  jointly authored (Samu Lang + Jesse Wright), with no CSS/server or
  fork-internal dependencies (only `@jeswr/solid-webauthn-protocol`,
  `@simplewebauthn/browser`, `oauth4webapi`). The only changes are cosmetic
  (workspace Biome style) so they lint here.
- **Reused unchanged (contract):** the `@jeswr/solid-webauthn-protocol` wire
  package — the single source of truth shared with the server.
- **Genuinely new (the ~4 lines the divergence forces):** a self-contained
  `WebAuthnTokenProvider implements TokenProvider` that owns the DPoP
  keypair/binding the published library buries inside its non-extensible
  `DPoPTokenProvider`, re-expressed against the **shared** `TokenProvider`
  interface so it drops into the apps' pipeline with no change to either
  reactive-auth distribution.

We did **not** depend the apps on the `reactive-authentication-js` fork (it is
unpublished and not a workspace member), nor fork `@solid/reactive-authentication`
to re-add the Strategy seam (a larger, riskier change to a library the apps
depend on). The provider re-declares the `TokenProvider` interface locally rather
than importing it, keeping this package free of a runtime dependency on either
reactive-auth distribution.

## Not wired into Pod Manager (yet)

Per the A5 brief, this round delivers the library + tests only; wiring it into
Pod Manager's 401-upgrade pipeline is deferred to avoid colliding with the
typed-views work in that repo.
