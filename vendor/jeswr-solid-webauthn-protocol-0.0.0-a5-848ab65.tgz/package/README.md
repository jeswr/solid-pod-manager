# @jeswr/solid-webauthn-protocol

Shared wire-format types + constants for the [Solid WebAuthn](../../spec/ARCHITECTURE.md)
mechanism — the single source of truth consumed by both the server
(`@jeswr/css-webauthn`) and the client (the `reactive-authentication-js` fork's
`WebAuthnTokenProvider`).

## Public API

**Constants**
- `WEBAUTHN_ASSERTION_TOKEN_TYPE = "urn:solid:token-type:webauthn-assertion"`
- `TOKEN_EXCHANGE_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:token-exchange"`
- `BUNDLE_VERSION = 1`

**Types** (WebAuthn JSON shapes reused from `@simplewebauthn/browser`, `decisions/0013`)
- `RegistrationOptions` = `PublicKeyCredentialCreationOptionsJSON`
- `AssertionOptions` = `PublicKeyCredentialRequestOptionsJSON`
- `RegistrationBundle = { version; credential: RegistrationResponseJSON; clientId }`
- `AssertionBundle = { version; credential: AuthenticationResponseJSON }`
- (re-exported) `RegistrationResponseJSON`, `AuthenticationResponseJSON`, and the
  two options-JSON types.

**Codec** (assertion bundle ⇄ `subject_token`)
- `encodeAssertionBundle(b: AssertionBundle): string` — base64url of UTF-8 JSON
- `decodeAssertionBundle(token: string): AssertionBundle` — throws
  `MalformedBundleError` on bad base64url / non-JSON / wrong shape / unknown `version`
- `encodeBase64url` / `decodeBase64url` — portable (Node + browser) helpers

**Origin helpers** (`spec/ARCHITECTURE.md` §8.2)
- `normaliseOrigin(o: string): string` — `scheme://host[:port]`, lowercased,
  default port elided, no path
- `allowedOriginsFor(clientId: string): string[]` — v1 (`decisions/0011`) =
  `[normaliseOrigin(new URL(clientId).origin)]`

> The WebAuthn JSON types come from `@simplewebauthn/browser` rather than the
> deprecated `@simplewebauthn/types`; `browser` re-exports the identical
> definitions, carries no Node crypto deps, and so suits this shared
> client+server contract.
